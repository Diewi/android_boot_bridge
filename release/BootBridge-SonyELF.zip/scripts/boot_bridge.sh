#!/sbin/sh
#
# Copyright (C) 2016 Adrian DC
#

# Constants
PARTITIONS_PATH=/dev/block/platform/msm_sdcc.1/by-name;
BOOTIMAGE_KERNEL=${PARTITIONS_PATH}/Kernel;
BOOTIMAGE_TEMPLATE=${PARTITIONS_PATH}/android_boot;

# Variables
BRIDGE_CREATED=;
RESULT=;

# Bridge mode detection
if [ -z "${1}" ] && [ -f "${BOOTIMAGE_TEMPLATE}" ]; then
  BRIDGE_CREATED=true;
fi;

# Path setup
cd /tmp/;

# Bridge creation
if [ -z "${BRIDGE_CREATED}" ]; then

  # Remove template leftovers
  rm -f ${BOOTIMAGE_TEMPLATE}.img;
  rm -f ${BOOTIMAGE_TEMPLATE};

  # Template creation
  cp -f /tmp/boot_bridge/boot_template.img ${BOOTIMAGE_TEMPLATE}.img;
  ln -s ${BOOTIMAGE_TEMPLATE}.img ${BOOTIMAGE_TEMPLATE};
  chmod 777 ${BOOTIMAGE_TEMPLATE};

  # Transfer to template
  chmod 755 /tmp/boot_bridge/boot_bridge;
  /tmp/boot_bridge/boot_bridge --import="${BOOTIMAGE_KERNEL}" --export="${BOOTIMAGE_TEMPLATE}";
  RESULT=${?};

  # Rename fstab targets
  if [ ${RESULT} -eq 0 ]; then
    sed -i "s|${BOOTIMAGE_KERNEL}|${BOOTIMAGE_TEMPLATE}|" /etc/recovery.fstab*;
    sed -i "s|${BOOTIMAGE_KERNEL}|${BOOTIMAGE_TEMPLATE}|" /fstab.*;

  # Cleanup failures
  else
    rm -f ${BOOTIMAGE_TEMPLATE}.img;
    rm -f ${BOOTIMAGE_TEMPLATE};
    sed -i "s|${BOOTIMAGE_TEMPLATE}|${BOOTIMAGE_KERNEL}|" /etc/recovery.fstab*;
    sed -i "s|${BOOTIMAGE_TEMPLATE}|${BOOTIMAGE_KERNEL}|" /fstab.*;
  fi;

# Bridge restore
else

  # Transfer to bootimage
  chmod 755 /tmp/boot_bridge/boot_bridge;
  /tmp/boot_bridge/boot_bridge --import="${BOOTIMAGE_TEMPLATE}" --export="${BOOTIMAGE_KERNEL}";
  RESULT=${?};

  # Remove template
  rm -f ${BOOTIMAGE_TEMPLATE}.img;
  rm -f ${BOOTIMAGE_TEMPLATE};

  # Rename fstab targets
  sed -i "s|${BOOTIMAGE_TEMPLATE}|${BOOTIMAGE_KERNEL}|" /etc/recovery.fstab*;
  sed -i "s|${BOOTIMAGE_TEMPLATE}|${BOOTIMAGE_KERNEL}|" /fstab.*;

fi;

# Result output
return ${RESULT};

